﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(HW2_HomePage.Startup))]
namespace HW2_HomePage
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
