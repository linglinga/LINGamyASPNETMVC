﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HW2_HomePage.Models;

namespace HW2_HomePage.Controllers
{
    public class HomeController : Controller
    {
        //GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        // Thess 3 needs to return a view of a form
        public ActionResult ClassList()
        {
            return View();  
        }

        public ActionResult StudentClasses()
        {
            return View();
        }

        public ActionResult EnrollInClass()
        {
            return View();
        }
    }
}